from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def home(request):
    return render(request,'home.html',{'name':'Ankit','personality':'Best'})

def add(request):
    num1=request.POST["n1"]
    num2=request.POST["n2"]
    result= int(num1)+int(num2)
    return render(request,'result.html',{'result':result})